<?php
/**
 * 百度地图相关业务封装
 */
class Map
{
    /**
     * 根据地址获取经纬度
     * @param $address
     * @return array
     */
    public static function getLngLat($address)
    {
        //http://api.map.baidu.com/geocoder/v2/?callback=renderOption&output=json&address=百度大厦&city=北京市&ak=您的ak
        //拼接接口后面的参数
        // ak 存在 extra/map.php 配置文件下
        if(empty($address) || !isset($address)) {
            return '';
        }

        $data = [
            'address' => $address,
            'ak' => config('map.ak'),   //从 extra/map.php 获取 ak
            'output' => 'json',
        ];
        $url = config('map.baidu_map_url').config('map.geocoder').'?'
                .http_build_query($data); // 将数组转换成请求的链接形式http_build_query
        $result = doCurl($url);
        if($result)
        {
            return json_decode($result,true);   //返回json
        }
        else
        {
            return [];
        }
//        return $result;
    }
    // http://api.map.baidu.com/staticimage/v2
    public static function  getStaticImage($center)
    {
        if(empty($center) || !isset($center))
        {
            return '';
        }
        $data = [
            'ak' => config('map.ak'),   //从 extra/map.php 获取 ak
            'width' => config('map.width'),
            'height' => config('map.height'),
            'center' => $center,
            'markers' => $center,
        ];
        $url = config('map.baidu_map_url').config('map.staticimage').'?'
            .http_build_query($data); // 将数组转换成请求的链接形式http_build_query
        $result = doCurl($url);
        return $result;
    }
}
?>